import 'package:flutter/material.dart';

import '../models/food_model.dart';
import '../services/food_service.dart';

class EditFoodScreen extends StatefulWidget {
  final FoodModel food;

  const EditFoodScreen({
    super.key,
    required this.food,
  });

  @override
  State<EditFoodScreen> createState() => _EditFoodScreenState();
}

class _EditFoodScreenState extends State<EditFoodScreen> {
  late TextEditingController nombreController;
  late TextEditingController cantidadController;

  late String categoria;
  late DateTime fechaVencimiento;

  bool loading = false;

  final categorias = [
    "Frutas",
    "Verduras",
    "Lácteos",
    "Carnes",
    "Bebidas",
    "Granos",
    "Snacks",
    "Otros",
  ];

  @override
  void initState() {
    super.initState();

    nombreController = TextEditingController(
      text: widget.food.nombre,
    );

    cantidadController = TextEditingController(
      text: widget.food.cantidad.toString(),
    );

    categoria = widget.food.categoria;
    fechaVencimiento = widget.food.fechaVencimiento;
  }

  Future<void> seleccionarFecha() async {
    final fecha = await showDatePicker(
      context: context,
      initialDate: fechaVencimiento,
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );

    if (fecha != null) {
      setState(() {
        fechaVencimiento = fecha;
      });
    }
  }

  Future<void> actualizar() async {
    if (nombreController.text.trim().isEmpty ||
        cantidadController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Completa todos los campos"),
        ),
      );
      return;
    }

    setState(() {
      loading = true;
    });

    try {
     final actualizado = FoodModel(
  id: widget.food.id,
  nombre: nombreController.text.trim(),
  categoria: categoria,
  cantidad: int.parse(cantidadController.text),
  fechaVencimiento: fechaVencimiento,
  usuarioId: widget.food.usuarioId,
);

      await FoodService.updateFood(actualizado);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Alimento actualizado"),
          backgroundColor: Colors.green,
        ),
      );

      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString()),
          backgroundColor: Colors.red,
        ),
      );
    }

    if (mounted) {
      setState(() {
        loading = false;
      });
    }
  }

  @override
  void dispose() {
    nombreController.dispose();
    cantidadController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 700;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F8F2),
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Editar alimento"),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            width: isMobile ? double.infinity : 450,
            margin: const EdgeInsets.all(25),
            padding: const EdgeInsets.all(30),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(25),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha(20),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              children: [
                const Icon(
                  Icons.edit,
                  size: 70,
                  color: Colors.orange,
                ),

                const SizedBox(height: 20),

                TextField(
                  controller: nombreController,
                  decoration: const InputDecoration(
                    labelText: "Nombre",
                    prefixIcon: Icon(Icons.fastfood),
                    border: OutlineInputBorder(),
                  ),
                ),

                const SizedBox(height: 20),

                DropdownButtonFormField<String>(
                  initialValue: categoria,
                  decoration: const InputDecoration(
                    labelText: "Categoría",
                    border: OutlineInputBorder(),
                  ),
                  items: categorias
                      .map(
                        (e) => DropdownMenuItem(
                          value: e,
                          child: Text(e),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      categoria = value!;
                    });
                  },
                ),

                const SizedBox(height: 20),

                TextField(
                  controller: cantidadController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: "Cantidad",
                    prefixIcon: Icon(Icons.numbers),
                    border: OutlineInputBorder(),
                  ),
                ),

                const SizedBox(height: 20),

                ListTile(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: const BorderSide(color: Colors.grey),
                  ),
                  leading: const Icon(
                    Icons.calendar_month,
                    color: Colors.green,
                  ),
                  title: const Text("Fecha de vencimiento"),
                  subtitle: Text(
                    "${fechaVencimiento.day}/${fechaVencimiento.month}/${fechaVencimiento.year}",
                  ),
                  trailing: ElevatedButton(
                    onPressed: seleccionarFecha,
                    child: const Text("Cambiar"),
                  ),
                ),

                const SizedBox(height: 30),

                SizedBox(
                  width: double.infinity,
                  height: 55,
                  child: ElevatedButton(
                    onPressed: loading ? null : actualizar,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      foregroundColor: Colors.white,
                    ),
                    child: loading
                        ? const CircularProgressIndicator(
                            color: Colors.white,
                          )
                        : const Text(
                            "Actualizar alimento",
                            style: TextStyle(fontSize: 18),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}