import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/food_model.dart';

class FoodService {
  FoodService._();

  static final FirebaseFirestore db = FirebaseFirestore.instance;

  static String get uid => FirebaseAuth.instance.currentUser!.uid;

  // Agregar alimento
  static Future<void> addFood(FoodModel food) async {
    await db.collection('alimentos').add(food.toMap());
  }

  // Obtener alimentos del usuario
  static Stream<List<FoodModel>> getFoods() {
    return db
        .collection('alimentos')
        .where('usuarioId', isEqualTo: uid)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map(
                (doc) => FoodModel.fromMap(
                  doc.id,
                  doc.data(),
                ),
              )
              .toList(),
        );
  }

  // Eliminar alimento
  static Future<void> deleteFood(String id) async {
    await db.collection('alimentos').doc(id).delete();
  }

  // Editar alimento
  static Future<void> updateFood(FoodModel food) async {
    await db.collection('alimentos').doc(food.id).update(food.toMap());
  }
}