import 'package:flutter/material.dart';
import '../models/food_model.dart';

class FoodCard extends StatelessWidget {
  final FoodModel food;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const FoodCard({
    super.key,
    required this.food,
    required this.onEdit,
    required this.onDelete,
  });

  String get imageUrl {
    switch (food.categoria.toLowerCase()) {
      case "frutas":
        return "https://images.unsplash.com/photo-1619566636858-adf3ef46400b?w=400";

      case "verduras":
        return "https://images.unsplash.com/photo-1542838132-92c53300491e?w=400";

      case "carnes":
        return "https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400";

      case "lácteos":
      case "lacteos":
        return "https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400";

      case "bebidas":
        return "https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400";

      default:
        return "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400";
    }
  }

  Color get statusColor {
    if (food.diasRestantes <= 2) {
      return Colors.red;
    } else if (food.diasRestantes <= 5) {
      return Colors.orange;
    }
    return Colors.green;
  }

  double get progress {
    if (food.diasRestantes <= 2) return .2;
    if (food.diasRestantes <= 5) return .5;
    return .9;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 8,
      ),
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [

            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.network(
                    imageUrl,
                    width: 85,
                    height: 85,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) {
                      return Container(
                        width: 85,
                        height: 85,
                        color: Colors.green.shade100,
                        child: const Icon(
                          Icons.fastfood,
                          color: Colors.green,
                          size: 40,
                        ),
                      );
                    },
                  ),
                ),

                const SizedBox(width: 16),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Text(
                        food.nombre,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 4),

                      Text(
                        "${food.diasRestantes} días restantes",
                        style: TextStyle(
                          color: statusColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),

                      const SizedBox(height: 10),

                      ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: LinearProgressIndicator(
                          value: progress,
                          minHeight: 7,
                          backgroundColor: Colors.grey.shade200,
                          color: statusColor,
                        ),
                      ),

                      const SizedBox(height: 10),

                      Text(
                        "Cantidad: ${food.cantidad}",
                        style: const TextStyle(
                          color: Colors.grey,
                        ),
                      ),

                      Text(
                        food.categoria,
                        style: const TextStyle(
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            Row(
              children: [

                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: onEdit,
                    icon: const Icon(Icons.edit),
                    label: const Text("Editar"),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.orange,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),

                const SizedBox(width: 10),

                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: onDelete,
                    icon: const Icon(Icons.delete),
                    label: const Text("Eliminar"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}